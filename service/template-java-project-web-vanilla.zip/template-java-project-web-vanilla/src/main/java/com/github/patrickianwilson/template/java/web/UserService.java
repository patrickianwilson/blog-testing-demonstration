package com.github.patrickianwilson.template.java.web;

/**
 * Created by pwilson on 3/7/16.
 */
public interface UserService {
}

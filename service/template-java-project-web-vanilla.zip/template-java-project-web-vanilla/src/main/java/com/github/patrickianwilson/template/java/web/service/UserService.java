package com.github.patrickianwilson.template.java.web.service;

/**
 * Created by pwilson on 3/7/16.
 */
public class UserService {
}


#cleanup some administrative and bookeeping files that are not really needed.
rm README.md
rm LICENSE



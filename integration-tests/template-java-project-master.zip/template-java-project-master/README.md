# template-java-project
Some java project templates for quick starts.
